<!--footer area start-->
<style>
.text-center1,p,.fmenu{
    
    color:#fff;
}

</style>
<section class="bg3"> 
	<nav class="menusection navbar-inverse" style="background-color: #293d3d;padding: 25px;
    font-size: 20px;">
    	 <div class="container-fluid">
            <div class="navbar-header">
              <a class="navbar-brand" href="#"></a>    
           </div>
            <ul class="nav navbar-nav">
              <li class=""><a href="#"></a></li>
              <li><a href="#">ABOUT US </a></li>
              <li><a href="#">CONTACT </a></li>
              <li><a href="#">OUR TEAM</a></li>
            </ul>
             <ul class="nav navbar-nav " style="float:right;width: 38%;">
              <li><h4 class="textline" style="    color: #fff;
    font-size: 27px;padding: 10px;">Picks you need to win sent your inbox </h4></li>
                <form>
                    <div class="input-group ">
                      <input type="email" class="form-control" size="10" placeholder="Email Address" required="">
                      <div class="input-group-btn">
                        <button type="button" class="btn btn-danger">Subscribe</button>
                      </div>
                    </div>
                </form>
          </ul>
      </div>
	</nav>
</section>
<section class="">
<footer class="container-fluid footerbg" style="background-color: #222;
    padding: 15px;">
<div class="row">
 <div class="col-md-1"></div>
	<div class="col-md-2 text-center1">
   <p><a href="#"class="fmenu">Help</a></p>
    <p><a href="#"class="fmenu">Live chat</a></p>
    <p><a href="#"class="fmenu">Teram &amp;condition</a></p>
    <p><a href="#"class="fmenu">premier leguge- Beting</a></p>
    <p><a href="#"class="fmenu">Esport Betting</a></p>
    <p><a href="#"class="fmenu">Online Blackjack</a></p>
    </div>     
	
    <div class="col-md-2">                                 
    <p><a href="#"class="fmenu">Help</a></p>
    <p><a href="#"class="fmenu">Live chat</a></p>
    <p><a href="#"class="fmenu">Teram &amp;condition</a></p>
    <p><a href="#"class="fmenu">premier leguge- Beting</a></p>
    <p><a href="#"class="fmenu">Esport Betting</a></p>
    <p><a href="#"class="fmenu">Online Blackjack</a></p>
    </div>             
	
    <div class="col-md-2">                                 
    <p><a href="#"class="fmenu">Help</a></p>
    <p><a href="#"class="fmenu">Live chat</a></p>
    <p><a href="#"class="fmenu">Teram &amp;condition</a></p>
    <p><a href="#"class="fmenu">premier leguge- Beting</a></p>
    <p><a href="#"class="fmenu">Esport Betting</a></p>
    <p><a href="#"class="fmenu">Online Blackjack</a></p>
    </div>
     <div class="col-md-2">
     <p><a href="#"class="fmenu">Help</a></p>
    <p><a href="#"class="fmenu">Live chat</a></p>
    <p><a href="#"class="fmenu">Teram &amp;condition</a></p>
    <p><a href="#"class="fmenu">premier leguge- Beting</a></p>
    <p><a href="#"class="fmenu">Esport Betting</a></p>
    <p><a href="#"class="fmenu">Online Blackjack</a></p>
     </div>
      <div class="col-md-2">
      <p><a href="#"class="fmenu">Help</a></p>
    <p><a href="#"class="fmenu">Live chat</a></p>
    <p><a href="#"class="fmenu">Teram &amp;condition</a></p>
    <p><a href="#"class="fmenu">premier leguge- Beting</a></p>
    <p><a href="#"class="fmenu">Esport Betting</a></p>
    <p><a href="#"class="fmenu">Online Blackjack</a></p>
      </div>
      <div class="col-md-1"></div>
</div>
</footer>
</section>


<footer class="footer-area" style="background: #293d3d;">
    <div class="footer-bottom">
        
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-sm-12">
                    <p class="copyright-text ">
                        {!! $basic->copyright !!}
                    </p>
                </div>
                <div class="col-md-3 col-sm-9">
                    <div class="footer-menu">
                        <ul>
                            @foreach($social as $data)
                            <li> <a href="{{url($data->link)}}" style="font-size: 18px">{!! $data->code !!}</a></li>
                            @endforeach
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="back-to-top" class="scroll-top back-to-top" data-original-title="" title="" >
        <i class="fa fa-angle-up"></i>
    </div>
</footer>