<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Event;
use App\BetOption;
use App\Match;
use App\BetQuestion;
use Carbon\Carbon;


use App\Menu;
use App\Faq;
use App\Advertisment;

class FrontendController extends Controller{

    public function __construct()
    {
        $now = Carbon::now();
        $data = Match::where('end_date','<', $now)->get();
        foreach ($data as $d) {
            $d->status = 2;
            $d->save();
        }


    }

    public function index()
    {
        $now = Carbon::now();
        $data['page_title'] = "Home";
        $data['matches'] = Match::whereStatus(1)->where('status', '!=' ,2)->where('start_date','<=', $now)->where('end_date','>', $now)->latest()->take(7)->get();
        return view('front.index',$data);
    }
    public function viewMore()
    {
        $now = Carbon::now();
        $data['page_title'] = "All Match";

        $data['matches'] = Match::whereStatus(1)->where('status', '!=' ,2)->where('start_date','<=', $now)->where('end_date','>', $now)->latest()->get();
        return view('front.all-match',$data);
    }

    public function matches($id)
    {
        $title = Event::find($id);
        $data['page_title'] = "$title->name All Matches";
        $now = Carbon::now();
        $data['matches'] = Match::whereEvent_id($id)->whereStatus(1)->where('status', '!=' ,2)->where('start_date','<=', $now)->where('end_date','>', $now)->latest()->get();
        return view('front.events',$data);
    }



    public function question($id)
    {
        $now = Carbon::now();
        $title = $data['match'] = Match::find($id);
        $data['page_title'] = "$title->name ";
        $data['question'] = BetQuestion::whereMatch_id($id)->whereStatus(1)->where('end_time','>=', $now)->get();
        return view('front.match-question',$data);
    }

    public function questionByMatch($id)
    {
        $data['ques'] = $ques =  BetQuestion::whereId($id)->first();
        $data['page_title'] = "$ques->question";
        $data['bets'] = BetOption::whereQuestion_id($id)->whereStatus(1)->get();
        return view('front.betOption',$data);
    }

    public function menu($slug)
    {
        $menu = $data['menu'] =  Menu::whereSlug($slug)->first();
        $data['page_title'] = "$menu->name";
        return view('layouts.menu',$data);
    }
    public function about()
    {
        $data['page_title'] = "About Us";
        return view('layouts.about',$data);
    }

    public function faqs()
    {
        $data['faqs'] =  Faq::all();
        $data['page_title'] = "Faqs";
        return view('layouts.faqs',$data);
    }


    public function contactUs()
    {
        $data['page_title'] = "Contact Us";
        return view('layouts.contact',$data);
    }

    public function contactSubmit(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'message' => 'required'
        ]);
        $subject = "Contact Us";
        send_email($request->email,$request->name, $subject,$request->message);
        $notification =  array('message' => 'Contact Message Send.', 'alert-type' => 'success');
        return back()->with($notification);
    }

    public function clickadd($id){

        $add = Advertisment::findOrFail($id);
        $data = array();
        $data['views'] = $add->views+1;
        Advertisment::whereId($id)->update($data);
        $go = $add->link;
        return redirect($go);
    }

    public function register($reference)
    {
        $page_title = "Sign Up";
        return view('auth.register',compact('reference','page_title'));
    }


}
