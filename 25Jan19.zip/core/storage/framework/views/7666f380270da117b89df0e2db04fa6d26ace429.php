<div class="widget-content">
        <div class="inplay_title">
            <h4>In-Play</h4>
        </div>


    <div class="widget__content card__content extar-margin">
        <div class="panel-group" id="accordion">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel pad1">
                <div class="panel-heading side-events-item">

                        <div class="left">
                            <?php
                                $slug =$data->slug
                            ?>
                            <a href="<?php echo e(url('events/'.$data->id."/$slug")); ?>"><b><?php echo e($data->name); ?></b></a>
                        </div>
                        <?php if(count( $data->inplayes) > 0 ): ?>
                        <div class="right">
                            <a data-toggle="collapse" data-parent="#accordion"
                                              href="#collapse<?php echo e($data->id); ?>"><i class="fa fa-plus"></i>
                            </a>
                        </div>
                        <?php endif; ?>

                </div>

                <div id="collapse<?php echo e($data->id); ?>" class="panel-collapse collapse">
                    <div class="panel-body live-match-body">
                        <div class="live-matches-sidebar">
                            <ul>
                                <?php $__currentLoopData = $data->inplayes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php $slug = str_slug($match->name)?>
                                    <a href="<?php echo e(url('/match/'.$match->id.'/'.$slug)); ?>">
                                        <i class="fa fa-arrow-right"></i> <?php echo e($match->name); ?> </a>

                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

