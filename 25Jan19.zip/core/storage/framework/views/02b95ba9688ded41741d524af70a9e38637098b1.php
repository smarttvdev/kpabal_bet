<?php $__env->startSection('body'); ?>
    <div class="page-content-wrapper">
        <div class="page-content">

            <h3 class="page-title uppercase bold"> <?php echo e($page_title); ?>


                <a href="<?php echo e(route('add.match')); ?>" class="btn btn-success pull-right btn-md  edit_button">
                    <i class="fa fa-plus"></i> Add Match
                </a>
            </h3>
            <hr>
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                        <i class="icon-settings font-dark"></i>
                        <span class="caption-subject bold uppercase">Match LIST</span>
                    </div>
                    <div class="tools"></div>
                    <div class="actions">
                        <form method="POST" class="form-inline" action="<?php echo e(route('admin.search.matches')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="text" name="search" class="form-control" placeholder="Search">
                            <button class="btn btn-outline btn-circle btn-sm green" type="submit"><i
                                        class="fa fa-search"></i></button>

                        </form>
                    </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover" id="">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Event</th>
                            <th>Questions</th>
                            <th>Options</th>
                            <th>STATUS</th>
                            <th style="width: 18%;">ACTION</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$mac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$k); ?></td>
                                <td><?php echo e(isset($mac->name) ? $mac->name : 'N/A'); ?></td>

                                <td>
                                    <strong><?php echo e(isset($mac->event->name) ? $mac->event->name : 'N/A'); ?></strong>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view.question', $mac->id )); ?>" class="btn btn-info btn-md edit_button" title="View Question">
                                        <strong><?php echo e($mac->questions()->count()); ?></strong>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view.allOption', $mac->id )); ?>" class="btn btn-warning btn-md edit_button" title="View Option">
                                        <strong><?php echo e($mac->options()->count()); ?></strong>
                                    </a>
                                </td>

                                <td>
                                    <b class="btn btn-sm btn-<?php echo e($mac->status ==0 ? 'warning' : 'success'); ?>"><?php echo e($mac->status == 0 ? 'Deactive' : 'Active'); ?></b>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('edit.match', $mac->id )); ?>" class="btn purple btn-sm edit_button">
                                        <i class="fa fa-edit"></i> EDIT
                                    </a>
                                    
                                        
                                    

                                    <a href="<?php echo e(route('view.question', $mac->id )); ?>" class="btn green btn-sm edit_button" title="View Question">
                                        <i class="fa fa-eye"></i>
                                    </a>

                                    <a href="<?php echo e(route('add.option', $mac->id )); ?>" class="btn blue-dark btn-sm edit_button" title="Bet Option">
                                        <i class="fa fa-check-circle"></i>
                                    </a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo $matches->links(); ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>