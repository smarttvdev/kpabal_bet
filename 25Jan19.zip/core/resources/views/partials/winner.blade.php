
<div class="widget-content">
    <div class="widget__title card__header card__header--has-btn">
        <div class="widget_title1">
            <h4>Winners</h4>
        </div>
    </div>
    <div class="widget__content card__content" style="margin-top: 5px;">
        <div class="panel-group vertical-slide">


            <div class="panel">
                <div class="panel-heading side-events-item">
                    <div class="">
                        <a href="http://localhost/bid_win/results/27">ronnie</a>
                    </div>
                </div>
            </div>
            <div class="panel">
                <div class="panel-heading side-events-item">
                    <div class="">
                        <a href="http://localhost/bid_win/results/27">ronnie</a>
                    </div>
                </div>
            </div>
            <div class="panel">
                <div class="panel-heading side-events-item">
                    <div class="">
                        <a href="http://localhost/bid_win/results/27">ronnie</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>