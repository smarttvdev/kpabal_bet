<?php $__env->startSection('body'); ?>
    <div class="page-content-wrapper">
        <div class="page-content">

            <h3 class="page-title uppercase bold"> <?php echo e($page_title); ?>


            </h3>
            <hr>
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                        <i class="icon-settings font-dark"></i>
                        <span class="caption-subject bold uppercase">Match LIST</span>
                    </div>
                    <div class="tools"></div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover" id="">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Event</th>
                            <th>End Time</th>
                            <th style="width: 15%;"> Bet Amount</th>
                            <th style="width: 15%;"> Return Amount</th>
                            <th>STATUS</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$mac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$k); ?></td>
                                <td><?php echo e(isset($mac->name) ? $mac->name : 'N/A'); ?></td>
                                <td>
                                    <strong><?php echo e(isset($mac->event->name) ? $mac->event->name : 'N/A'); ?></strong>
                                </td>

                                <td>
                                    <?php echo e(Carbon\carbon::parse($mac->end_date)->format('d M Y H:i A')); ?>

                                </td>


                                <td>
                                    <button class="btn btn-success btn-md " >
                                        <strong><?php echo e($mac->betInvests()->sum('invest_amount')); ?> <?php echo $basic->currency; ?></strong>
                                    </button>
                                </td>

                                <td>
                                    <button class="btn btn-warning btn-md " >
                                        <strong><?php echo e($mac->betInvests()->sum('return_amount')); ?> <?php echo $basic->currency; ?></strong>
                                    </button>
                                </td>


                                <td>
                                    <b class="btn btn-md btn-<?php echo e($mac->status ==2 ? 'danger' : 'success'); ?>"><?php echo e($mac->status == 2 ? 'Closed' : 'Active'); ?></b>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo $matches->links(); ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>