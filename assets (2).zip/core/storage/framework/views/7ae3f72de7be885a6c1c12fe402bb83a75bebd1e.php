
<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--about us page content start-->
    <section class="section-padding about-us-page ">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $basic->about; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>