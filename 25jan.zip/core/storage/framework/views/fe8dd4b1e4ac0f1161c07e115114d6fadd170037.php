
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/table.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('nic', ' '); ?>
<?php $__env->startSection('body'); ?>
    <div class="page-content-wrapper">
        <div class="page-content">

            <h3 class="page-title uppercase bold"> <?php echo e($page_title); ?></h3>
            <hr>
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-red-sunglo">
                        <i class="lotn-settings font-red-sunglo"></i>
                        <span class="caption-subject bold uppercase">Ads Management</span>
                    </div>
                    <div class="actions">
                        <a href="<?php echo e(route('advertisement.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i>
                            Add New</a>
                    </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-bordered">
                        <thead>
                        <th scope="col">Ad Type</th>
                        <th scope="col">Banner/Script</th>
                        <th scope="col">Clicks</th>
                        <th scope="col">Action</th>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="row_<?php echo e($data->id); ?>">
                                <td data-label="Ad Type">
                                    <?php if($data->type ==1): ?>
                                        <strong>Banner</strong>
                                    <?php else: ?>
                                        <strong>Script</strong>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Banner / Script">
                                    <?php if($data->size == 1): ?>
                                        <h6>300x250</h6>
                                    <?php elseif($data->size == 2): ?>
                                        <h6>728x90</h6>
                                    <?php else: ?>
                                        <h6>300x600</h6>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Ad Size">
                                    <span href="" class="btn btn-success btn-sm">
                                         <?php echo $data->views; ?>

                                    </span>
                                </td>
                                <td data-label="Action">
                                    <a class="btn btn-sm btn-info modal_button delete_button" data-toggle="modal"
                                       data-target="#small<?php echo e($data->id); ?>" value="3" data-src="<?php echo e($data->id); ?>"
                                       data-status="<?php echo e($data->id); ?>" data-sub="<?php echo e($data->id); ?>"><i class="fa fa-eye"></i>
                                        Show</a>
                                    <a class="btn btn-danger btn-sm" data-id="<?php echo e($data->id); ?>" href="#"
                                       data-toggle="modal" data-target="#advertise-delete-data<?php echo e($data->id); ?>"
                                       id="advert_delete_btn">Delete</a>
                                </td>
                            </tr>



                            <!--advertise delete modal-->
                            <div class="modal fade" id="advertise-delete-data<?php echo e($data->id); ?>" tabindex="-1"
                                 role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Advertise Remove</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('advertisement.destroy', $data->id)); ?>"
                                          id="category_delete_form" method="POST" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <div class="modal-body">
                                            <input type="hidden" id="addvertise_id" value="<?php echo e($data->id); ?>"
                                                   name="addvertise_id">
                                            <h6class="text text-danger"><strong>Are Your Sure To Delete This Advertise
                                                    ?</strong></h3>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                                            </button>
                                            <button type="submit" class="btn red" id="delete_confirm">Confirm Delete
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>


                            <div class="modal fade" id="small<?php echo e($data->id); ?>" role="dialog"
                                 aria-labelledby="confirmDeleteLabel" aria-hidden="true">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                                        </button>
                                        <h4 class="modal-title"><b class="text-uppercase"> <span id="modal-heading">Advertisment Show</span>
                                            </b></h4>
                                    </div>
                                    <div class="modal-body">
                                        <?php if($data->type ==1): ?>
                                            <?php if(file_exists("assets/images/ads/add-pic-{$data->id}.{$data->src}")): ?>
                                                <img src="<?php echo e(url('/')); ?>/assets/images/ads/add-pic-<?php echo e($data->id); ?>.<?php echo e($data->src); ?>"
                                                     alt="Add Image" style="height: 300px; width: 400px;">
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <p cols="10" rows="10"><?php echo e($data->script); ?></p>
                                        <?php endif; ?>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal"
                                                id="confirm_delete_subcategory">Close
                                        </button>
                                    </div>
                                </div>

                            </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <?php echo $ads->links(); ?>

            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            /**====================================================
             * Dynamicaly Change the form by the advertise type
             * =================================================**/
            $(document).on('change', '#add_type', function () {
                var id = $(this).val();
                //alert(id);
                if (id == 0) {
                    $('#load_form_for_add').html("");

                } else if (id == 1) {
                    $('#load_form_for_add').html("");
                    $('#load_form_for_add').append('<div class="form-group">' +
                        '<label for="advertiser_name"> Advertiser Name</label>' +
                        '<input type="text" name="advertiser_name" placeholder="Advertiser Name" class="form-control">' +
                        '</div>' +
                        '<div class="form-group">' +
                        '<label for="redirect_url"> Redirect Url</label>' +
                        '<input type="text" name="redirect_url" placeholder="http://thesoftking.com" class="form-control">' +
                        '</div>' +
                        '<div class="form-group">' +
                        '<label for="add_picture">Banner</label>' +
                        '<input type="file" name="add_picture">' +
                        '</div>');
                } else {
                    $('#load_form_for_add').html("");
                    $('#load_form_for_add').append('<div class="form-group">' +
                        '<label for="script"> Advertiser Name</label>' +
                        '<textarea name="script" id="script" cols="30" rows="10" class="form-control" placeholder="Script will be here"></textarea>' +
                        '</div>');
                }
            });


        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>