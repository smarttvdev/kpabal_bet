<div class="showadd">
<?php if($adds->type == 1): ?>
    <a target="_blank" href="<?php echo e(url('/click-add/'.$adds->id)); ?>">
        <img src="<?php echo e(url('/')); ?>/assets/images/ads/add-pic-<?php echo e($adds->id); ?>.<?php echo e($adds->src); ?>" class="img-responsive" alt="*" style="width: 100%">
    </a>
<?php else: ?>
    <a target="_blank" href="<?php echo e(url('/click-add/'.$adds->id)); ?>">
        <?php echo $adds->script; ?>

    </a>
<?php endif; ?>
</div>