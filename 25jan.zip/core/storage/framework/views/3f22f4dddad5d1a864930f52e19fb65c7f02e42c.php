<?php $__env->startSection('content'); ?>

    <div class="bet-section" id="min-height-all-match">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <aside class="widget card widget--sidebar widget-standings">
                        <?php echo $__env->make('partials.event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo show_add(1); ?>

                        <?php echo show_add(3); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(3); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        
                    </aside>
                </div>
                <div class="col-md-6">
                    <?php $i =0 ;?>
                    <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                            $k++;
                                $slug =$data->slug
                        ?>
                        <div class="panel custom-panel-bg panel-default widget-content panel-content" style="margin-bottom:15px;">
                            <div class="panel-heading">
                                <div class="widget_title1">
                                    <a href="<?php echo e(url('match/'.$data->id.'/'.str_slug($data->name))); ?>">
                                        <h4><?php echo $data->name; ?></h4>
                                    </a>
                                </div>
                            </div>
                            <div class="panel-body bet-body">

                                <div class="col-md-12">
                                    <button class="btn btn-block bs-callout bs-callout-warning  ">
                                        Match Expire in <span id="tsk<?php echo e($data->id); ?>"><?php
                                                if($data->end_date){
                                                      $edate = Carbon\Carbon::parse($data->end_date);
                                                      $now = Carbon\Carbon::now();
                                                      $coutd = $edate->diffInSeconds($now);
                                                      $iid = "tsk".$data->id;
                                                      echo "<script>
                                                            $(function () {
                                                                var etm = $coutd;
                                                                var $iid = $('#$iid'),
                                                               ts = (new Date()).getTime() + etm * 1000;

                                                                $('#countdown').countdown({
                                                                    timestamp: ts,
                                                                    callback: function (days, hours, minutes, seconds) {

                                                                        var message = \"\";
                                                                        if (days>0) {
                                                                        message += days + \"Day  \" + \" \";
                                                                    }
                                                                        message += hours + \"h \" + \" \";
                                                                        message += minutes + \"m\" + \" \";
                                                                        message += seconds + \"s \" + \" \";
                                                                        $iid.html(message);
                                                                    }
                                                                });

                                                            });
                                                        </script>";
                                                      $i++;
                                                }else{
                                                echo "NO Date Announced";
                                                }
                                            ?></span>
                                    </button>
                                </div>

                                <div class="col-md-6">
                                    <a href="<?php echo e(url('match/'.$data->id.'/'.str_slug($data->name))); ?>"
                                       class="btn btn-block bs-callout bs-callout-warning bet-option text-center white"><?php echo e($data->questionsEndTime()->count()); ?>

                                        Bet Available </a>
                                </div>
                                <div class="col-md-4 col-md-offset-2">
                                    <a href="<?php echo e(url('match/'.$data->id.'/'.str_slug($data->name))); ?>"
                                       class="btn btn-block bs-callout bs-callout-warning bet-option text-center white">Continue... </a>
                                </div>

                            </div>
                        </div>
                        <?php if($k%2==0): ?>
                            <?php echo show_add(2); ?>

                        <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <aside>
                    <div class="col-md-3">

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(3); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(3); ?>

                        <?php echo show_add(1); ?>

                        <?php echo show_add(1); ?>

                        
                        <?php echo show_add(3); ?>


                    </div>
                </aside>

            </div>
        </div>

    </div>


    <script>
        (function ($) {
            $(window).on('resize', function () {
                var bodyHeight = $(window).height();
                $('#min-height-all-match').css('min-height', parseInt(bodyHeight) - 450);
                console.log(bodyHeight)
            })
            var bodyHeight = $(window).height();
            $('#min-height-all-match').css('min-height', parseInt(bodyHeight) - 450);
            console.log(bodyHeight)


        }(jQuery))
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>