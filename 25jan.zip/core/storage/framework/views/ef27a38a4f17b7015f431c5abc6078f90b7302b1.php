

<?php $__env->startSection('body'); ?>

    <div class="page-content-wrapper">
        <div class="page-content">
            <h3 class="page-title uppercase bold"> <?php echo e($page_title); ?>

                <a href="<?php echo e(route('admin.matches')); ?>" class="btn btn-success  btn-md pull-right edit_button">
                    <i class="fa fa-eye"></i> View Matches
                </a>
            </h3>
            <hr>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <form action="<?php echo e(route('update.match')); ?>" method="post" name="editForm">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($match->id); ?>">
                        <div class="form-group  ">
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon" id="sizing-addon1">Select Event</span>
                                <select name="event_id" id="" class="form-control">
                                    <option value="">Select Event</option>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if($match->event_id == $data->id): ?> selected <?php endif; ?>><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('event_id')): ?>
                                <div class="error"><?php echo e($errors->first('event_id')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group ">
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon" id="sizing-addon1">Match </span>
                                <input type="text" name="name" value="<?php echo e($match->name); ?>" class="form-control">
                            </div>
                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group ">
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon" id="sizing-addon1">Youtube Video </span>
                                <input type="text" name="src" value="<?php echo e($match->src); ?>" class="form-control" placeholder="Youtube Embedded Code">
                            </div>
                        </div>



                        <div class="form-group">
                            <div class="input-group input-group-lg ">
                                <span class="input-group-addon" id="sizing-addon1">Start Date</span>
                                <input type="text" value="<?php echo e(Carbon\carbon::parse($match->start_date)->format('d-m-Y  H:i:s ')); ?>" class="form-control input-lg datepicker" id="start_date" name="start_date">
                                <span class="input-group-btn">
                                        <button class="btn default" type="button">
                                            <i class="fa fa-calendar"></i>
                                        </button>
                                    </span>
                            </div>
                            <?php if($errors->has('start_date')): ?>
                                <div class="error"><?php echo e($errors->first('start_date')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <div class="input-group input-group-lg ">
                                <span class="input-group-addon" id="sizing-addon1">End Date</span>
                                <input type="text" value="<?php echo e(Carbon\carbon::parse($match->end_date)->format('d-m-Y H:i:s')); ?>" class="form-control input-lg datepicker" id="start_date" name="end_date">
                                <span class="input-group-btn">
                                        <button class="btn default" type="button">
                                            <i class="fa fa-calendar"></i>
                                        </button>
                                    </span>
                            </div>
                            <?php if($errors->has('end_date')): ?>
                                <div class="error"><?php echo e($errors->first('end_date')); ?></div>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <label for="" style="text-transform: uppercase; font-weight: bold">STATUS</label>
                            <input data-toggle="toggle" data-size="large" data-onstyle="success" data-offstyle="danger"
                                   data-width="100%" type="checkbox" data-on="Active" data-off="DeActive"
                                   name="status" <?php echo e($match->status == "1" ? 'checked' : ''); ?>>

                        </div>

                        <button type="submit" class="btn btn-success btn-lg btn-block">Save</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        

        $(document).ready(function () {
            $(function () {
                $('.datepicker').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm:ss'
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>