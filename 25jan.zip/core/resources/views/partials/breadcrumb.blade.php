<style type="text/css">
    .breadcrumb-section {
        background-image: url({{asset('assets/images/logo/breadcrumb.png')}});
    }

</style>
<!-- Breadcrumb Section start -->
<section class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- breadcrumb Section Start -->
                <div class="breadcrumb-content">
                    <h2>{{$page_title}}</h2>
                </div>
                <!-- Breadcrumb section End -->
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->
